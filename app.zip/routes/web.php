<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('form');
});
Route::get('/ex1', function () {
    return view('example1');
});
Route::get('/mail', function () {
    return view('mail');
});
Route::post('/post-form','App\Http\Controllers\BdrOssController@post');
Route::get('/kirim','App\Http\Controllers\BdrOssController@kirim');
